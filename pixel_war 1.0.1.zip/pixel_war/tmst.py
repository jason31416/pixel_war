flname = input("file name?")
fl = open(flname+".txt", "r")
rd = [i.split(" ") for i in fl.read().split("\n")]
fl.close()
print(len(rd), len(rd[0]))
nwworld = [["" for j in range(len(rd)*2)] for i in range(len(rd)*2)]

for i in range(len(rd)):
    for j in range(len(rd)):
        for k in range(2):
            for l in range(2):
                nwworld[i*2+k][j*2+l] = rd[i][j]

fl = open(flname+".txt", "w+")
for i in range(len(rd)*2):
    for j in range(len(rd) * 2):
        if j < len(rd) * 2 - 1:
            fl.write(nwworld[i][j]+" ")
        else:
            fl.write(nwworld[i][j])
    if i < len(rd)*2-1:
        fl.write("\n")
fl.close()