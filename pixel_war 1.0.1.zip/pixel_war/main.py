import math
import pygame
import random
import time
import copy

# themes

bgclr = (255, 255, 255)
blclr = (200, 200, 200)
wtclr = (130, 255, 255)
ctclr = (255, 215, 0)

# functions

def calcdis(p1, p2):
    return abs(p1[0]-p2[0])+abs(p1[1]-p2[1])

# init

pygame.init()
sc = pygame.display.set_mode((800, 600))

wname = input("map name?")

fl = open(wname+".txt", "r")
rd = fl.read().split("\n")
fl.close()

wsize = len(rd)

world = [[0]*wsize for i in range(wsize)]

aitarg = []

for i in range(wsize):
    for j in range(wsize):
        if rd[i].split(" ")[j] == "-":
            world[j][i] = -1
        elif rd[i].split(" ")[j] == "=":
            world[j][i] = -2
        elif rd[i].split(" ")[j] == "*":
            world[j][i] = -3
            aitarg.append((j, i))
        else:
            world[j][i] = int(rd[i].split(" ")[j])
troops = [[[0, 0, 0] for j in range(wsize)] for i in range(wsize)]
vx, vy = 0, 0

pnum = int(input("computer num?"))
pnum += 1

teamc = [(0, 0, 0)]

sfont = pygame.font.Font(None, 18)



avclrs = [(255, 255, 0), (255, 97, 0), (0, 0, 255), (255, 0, 0), (34, 139, 34), (128, 42, 0), (160, 32, 240), (0, 199, 140), (68, 78, 75), (0, 255, 255), (255, 0, 255)]

for i in range(pnum):
    tclr = random.choice(avclrs)
    avclrs.remove(tclr)
    teamc.append(tclr)
    if i == 0 or random.randint(0, 10) < 4:
        rx, ry = random.randint(0, wsize-1), random.randint(0, wsize - 1)
    else:
        rx, ry = random.choice(aitarg)
    while world[rx][ry] == -1 and troops[rx][ry][0] == 0:
        rx, ry = random.randint(0, wsize - 1), random.randint(0, wsize - 1)
    print(rx, ry, i, world[rx][ry])
    # world[rx][ry] = i+1
    troops[rx][ry] = [i+1, 1, 5]
    if i == 0:
        vx, vy = rx, ry

# main loop

stage = 0
troopsleft = 1
tcooldown = 0
mcooldown = 0
tick = 0
sx, sy = -1, -1

high1, high2 = pygame.transform.scale(pygame.image.load("high1.png"), (32, 32)), pygame.transform.scale(pygame.image.load("high2.png"), (32, 32))

yxl = [[[0]*12 for j in range(wsize)] for i in range(wsize)]

targs = [[(-1, -1) for j in range(wsize)] for i in range(wsize)]

hhcnt = 0

def calch(tpe):
    if tpe == -3:
        tpe = 0
    return tpe

def movet(x, y, ox, oy):
    global sx, sy
    if 0 <= x < wsize and 0 <= y < wsize and calch(world[ox][oy]) - calch(world[x][y]) >= -1:
        if troops[x][y][0] == 0 and troops[ox][oy][2] > 0:
            troops[x][y] = [troops[ox][oy][0], troops[ox][oy][1], troops[ox][oy][2] - 1]
            troops[ox][oy] = [0, 0, 0]
            sx, sy = x, y
        elif troops[x][y][0] == troops[ox][oy][0] and troops[x][y][2] > 0:
            troops[x][y] = [troops[x][y][0], troops[x][y][1]+troops[ox][oy][1], min(troops[x][y][2] - 1, troops[ox][oy][2])]
            troops[ox][oy] = [0, 0, 0]
            sx, sy = x, y
        elif troops[x][y][0] != troops[ox][oy][0] and troops[x][y][0] != 0:
            fight(x, y, ox, oy)

def fight(x1, y1, x2, y2):
    print(f"fight: {troops[x1][y1][0]} vs {troops[x2][y2][0]}", end=": ")
    rdlst = [0, 1]
    if world[x1][y1] == -1:
        rdlst.append(0)
        rdlst.append(0)
    if world[x2][y2] == -1:
        rdlst.append(1)
        rdlst.append(1)
    print(rdlst, end=", ")
    random.shuffle(rdlst)
    aa = random.choice(rdlst)
    print(aa, "loses")
    if aa == 0:
        troops[x1][y1][1] -= 1
        if troops[x1][y1][1] <= 0:
            troops[x1][y1] = [0, 0, 0]
            targs[x1][y1] = (-1, -1)
            return 2
    else:
        troops[x2][y2][1] -= 1
        if troops[x2][y2][1] <= 0:
            troops[x2][y2] = [0, 0, 0]
            targs[x2][y2] = (-1, -1)
            return 1
    return 0

while True:
    ticktime = time.time()
    sc.fill(bgclr)
    for i in range(int(vx) - 13, int(vx) + 14):
        if i < 0 or i >= wsize:
            continue
        for j in range(int(vy) - 9, int(vy) + 14):
            if j - 7 < 0 or j - 7 >= wsize:
                continue
            if world[i][j-7] >= 0:
                if max(yxl[i][j-7]) == 0:
                    pygame.draw.rect(sc, blclr, ((i - vx + 13) * 33, (j - vy + 5) * 33, 32, 32))
                else:
                    mxid = 0
                    for k in range(len(yxl[i][j-7])):
                        if yxl[i][j-7][k] > yxl[i][j-7][mxid]:
                            mxid = k
                    pygame.draw.rect(sc, (min(teamc[mxid][0]+75, 255)//2+blclr[0]//2, min(teamc[mxid][1]+75, 255)//2+blclr[1]//2, min(teamc[mxid][2]+75, 255)//2+blclr[2]//2), ((i - vx + 13) * 33, (j - vy + 5) * 33, 32, 32))
            elif world[i][j-7] == -1:
                pygame.draw.rect(sc, wtclr, ((i - vx + 13) * 33, (j - vy + 5) * 33, 32, 32))
            elif world[i][j-7] == -3:
                pygame.draw.rect(sc, ctclr, ((i - vx + 13) * 33, (j - vy + 5) * 33, 32, 32))
            if world[i][j-7] == 1:
                sc.blit(high1, ((i - vx + 13) * 33, (j - vy + 5) * 33, 32, 32))
            elif world[i][j-7] == 2:
                sc.blit(high2, ((i - vx + 13) * 33, (j - vy + 5) * 33, 32, 32))
            # elif world[i][j-7] > 0:
            #     pygame.draw.rect(sc, teamc[world[i][j-7]], ((i - vx + 13) * 33, (j - vy + 5) * 33, 32, 32))
            if troops[i][j-7][0] > 0:
                if sx == i and sy == j-7:
                    pygame.draw.rect(sc, (0, 0, 0), ((i - vx + 13) * 33 + 3, (j - vy + 5) * 33 + 3, 24, 24))
                pygame.draw.rect(sc, teamc[troops[i][j - 7][0]], ((i - vx + 13) * 33+5, (j - vy + 5) * 33+5, 20, 20))
                sc.blit(sfont.render(str(troops[i][j - 7][1]), False, (0, 0, 0)), ((i - vx + 13) * 33+11, (j - vy + 5) * 33+11))
                if troops[i][j-7][0] == 1:
                    if stage == 0 and troopsleft > 0 and yxl[i][j-7][1] == max(yxl[i][j-7]) and yxl[i][j-7][1] > 0 and tick - tcooldown >= 6 and pygame.rect.Rect((i - vx + 13) * 33+5, (j - vy + 5) * 33+5, 20, 20).collidepoint(pygame.mouse.get_pos()) and pygame.mouse.get_pressed()[0]:
                        troops[i][j - 7][1] += 1
                        tcooldown = tick
                        troopsleft -= 1
                    elif stage == 0 and troopsleft <= 0:
                        stage = 1
                    if stage == 1 and tick - tcooldown >= 25 and pygame.rect.Rect((i - vx + 13) * 33 + 5, (j - vy + 5) * 33 + 5, 20, 20).collidepoint(pygame.mouse.get_pos()) and pygame.mouse.get_pressed()[0]:
                        if sx == -1 or sx != i or sy != j-7:
                            sx, sy = i, j-7
                        else:
                            sx, sy = -1, -1
                        tcooldown = tick
    keys = pygame.key.get_pressed()
    if tick % 10 == 0:
        yxl = [[[0] * 12 for j in range(wsize)] for i in range(wsize)]
        for i in range(wsize):
            for j in range(wsize):
                if troops[i][j][0] > 0:
                    for k in range(max(0, i-5), min(wsize, i+6)):
                        for l in range(max(0, j-5), min(wsize, j+6)):
                            if math.sqrt((i-k)**2+(j-l)**2) <= 5 and world[k][l] != -1:
                                yxl[k][l][troops[i][j][0]] += troops[i][j][1]
    if keys[pygame.K_p] and stage == 0:
        stage = 1
    if keys[pygame.K_RETURN] and stage == 1:
        stage = 2
        sx, sy = -1, -1
        troopsleft = 1
        aistl = [1]*(pnum+1)
        if hhcnt >= 10 and random.randint(0, 7) == 0:
            allt = []
            for i in range(wsize):
                for j in range(wsize):
                    if troops[i][j][0] != 0:
                        allt.append((i, j))
            rxx, ryy = random.choice(allt)
            nw = random.randint(2, pnum)
            print(f"change: {troops[rxx][ryy][0]} -> {nw}")
            troops[rxx][ryy][0] = random.randint(2, pnum)
            troops[rxx][ryy][1] = random.choice([1, 1, 1, 1, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4, 5, 1, 1, 1, 1, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 2, 2, 2, 2, 2, 3])*troops[rxx][ryy][1]
            vx, vy = rxx, ryy
        for i in range(wsize):
            for j in range(wsize):
                if troops[i][j][0] != 0:
                    troops[i][j][2] = 5
                    if world[i][j] == -3:
                        if troops[i][j][0] == 1:
                            troopsleft += 1
                        else:
                            aistl[troops[i][j][0]] += 1
                if max(yxl[i][j]) != 0:
                    mxid = 0
                    for k in range(len(yxl[i][j])):
                        if yxl[i][j][k] > yxl[i][j][mxid]:
                            mxid = k
                    if mxid == 1:
                        troopsleft += 0.001
                    else:
                        aistl[mxid] += 0.001

        troopsleft = int(troopsleft)
        aistl = [int(i) for i in aistl]
        # todo: AIs
        for i in range(wsize):  # add
            for j in range(wsize):
                if troops[i][j][0] > 1 and world[i][j] == -3 and yxl[i][j][troops[i][j][0]] == max(yxl[i][j]) and random.randint(0, 1) == 0:
                    troops[i][j][1] += 1
                elif aistl[troops[i][j][0]] > 0 and yxl[i][j][troops[i][j][0]] == max(yxl[i][j]) and yxl[i][j][troops[i][j][0]] > 0 and troops[i][j][0] > 1:
                    bb = False
                    for k in range(max(i-5, 0), min(i+6, wsize)):
                        for l in range(max(j - 5, 0), min(j + 6, wsize)):
                            if troops[k][l][0] > 0 and troops[k][l][0] != troops[i][j][0] and aistl[troops[i][j][0]] > 0 and world[i][j] != -1:
                                troops[i][j][1] += 1
                                aistl[troops[i][j][0]] -= 1
                                bb = True
                                break
                        if bb:
                            break

        for i in range(wsize):  # add left
            for j in range(wsize):
                if troops[i][j][0] > 1 and aistl[troops[i][j][0]] > 0 and yxl[i][j][troops[i][j][0]] == max(yxl[i][j]) and world[i][j] != -1:
                    troops[i][j][1] += 1
                    aistl[troops[i][j][0]] -= 1

        for i in range(wsize):  # attack
            for j in range(wsize):
                if troops[i][j][0] > 1 and troops[i][j][1] >= 1 and world[i][j] != -3 and troops[i][j][2] > 0:
                    if targs[i][j][0] == -1:
                        for tx, ty in aitarg:
                            if troops[tx][ty][0] != troops[i][j][0] and calcdis(targs[i][j], (i, j)) > calcdis((tx, ty), (i, j)) >= 70:
                                targs[i][j] = (tx, ty)
                        if targs[i][j][0] == -1:
                            if troops[i][j][1] > 5 and i + 1 < wsize and troops[i + 1][j][0] == 0:
                                troops[i + 1][j] = [troops[i][j][0], troops[i][j][1] // 2, troops[i][j][2] - 1]
                                troops[i][j][1] = troops[i][j][1] - troops[i][j][1] // 2
                            validpos = []
                            bbb = False
                            for k in range(max(0, i - 8), min(wsize, i + 9)):
                                for l in range(max(0, j - 8), min(wsize, j + 9)):
                                    if (max(yxl[k][l]) != yxl[k][l][troops[i][j][0]] or max(yxl[k][l]) == 0) and troops[k][l][0] == 0 and \
                                            world[k][
                                                l] != -1:
                                        validpos.append((k, l))
                                    elif troops[i][j][0] != troops[k][l][0] != 0:
                                        targs[i][j] = (k, l)
                                        break
                                    elif troops[i][j][0] == troops[k][l][0]:
                                        bbb = True
                            if targs[i][j][0] == -1 and bbb and len(validpos) > 0:
                                targs[i][j] = random.choice(validpos)
                            else:
                                continue
                        if targs[i][j][0] == -1:
                            continue
                    if calcdis(targs[i][j], (i, j)) <= troops[i][j][2]:
                        if troops[i][j][1] > 5 and i + 1 < wsize and troops[i + 1][j][0] == 0:
                            troops[i + 1][j] = [troops[i][j][0], troops[i][j][1] // 2, troops[i][j][2] - 1]
                            troops[i][j][1] = troops[i][j][1] - troops[i][j][1] // 2
                        if troops[targs[i][j][0]][targs[i][j][1]][0] > 0 and troops[targs[i][j][0]][targs[i][j][1]][0] != troops[i][j][0]:
                            while troops[i][j][1] > 0 and troops[targs[i][j][0]][targs[i][j][1]][1] > 0:
                                res = fight(i, j, targs[i][j][0], targs[i][j][1])
                                if res != 0:
                                    if res == 1:
                                        troops[targs[i][j][0]][targs[i][j][1]] = [troops[i][j][0], troops[i][j][1],
                                                                                  troops[i][j][1] - calcdis(targs[i][j],
                                                                                                            (i, j))]
                                        troops[i][j] = [0, 0, 0]
                                        targs[i][j] = (-1, -1)
                                        targs[targs[i][j][0]][targs[i][j][1]] = (-1, -1)
                                    break
                        else:
                            troops[targs[i][j][0]][targs[i][j][1]] = [troops[i][j][0], troops[i][j][1],
                                                                      troops[i][j][1] - calcdis(targs[i][j],
                                                                                                (i, j))]
                            troops[i][j] = [0, 0, 0]
                            targs[i][j] = (-1, -1)
                            targs[targs[i][j][0]][targs[i][j][1]] = (-1, -1)
                    else:
                        for k in range(max(0, i - 5), min(wsize, i + 6)):
                            for l in range(max(0, j - 5), min(wsize, j + 6)):
                                if troops[k][l][0] > 0 and troops[k][l][0] != troops[i][j][0] and troops[i][j][1] > 1:
                                    while troops[i][j][1] > 1 and troops[k][l][1] > 0:
                                        res = fight(i, j, k, l)
                                        if res != 0:
                                            if res == 1:
                                                troops[k][l] = [troops[i][j][0], troops[i][j][1],
                                                                troops[i][j][2] - calcdis((i, j), (k, l))]
                                                troops[i][j] = [0, 0, 0]
                                                targs[k][l] = targs[i][j]
                                                targs[i][j] = (-1, -1)
                                                troops[i][j] = [0, 0, 0]
                                                targs[i][j] = (-1, -1)
                                                targs[targs[i][j][0]][targs[i][j][1]] = (-1, -1)
                                            break
                        if targs[i][j][0] != -1:
                            tx, ty = i, j
                            for k in range(troops[i][j][2]):
                                if targs[i][j][0] < tx and troops[tx - 1][ty][0] == 0:
                                    tx -= 1
                                elif targs[i][j][0] > tx and troops[tx + 1][ty][0] == 0:
                                    tx += 1
                                elif targs[i][j][1] < ty and troops[tx][ty - 1][0] == 0:
                                    ty -= 1
                                elif targs[i][j][1] > ty and troops[tx][ty + 1][0] == 0:
                                    ty += 1
                            if tx != i or ty != j:
                                troops[tx][ty] = [troops[i][j][0], troops[i][j][1], 0]
                                troops[i][j] = [0, 0, 0]
                                targs[tx][ty] = targs[i][j]
                                targs[i][j] = (-1, -1)
                elif troops[i][j][0] > 1 and troops[i][j][1] > 4 and world[i][j] == -3 and troops[i][j][2] > 0 and i+1 < wsize:
                    troops[i + 1][j] = [troops[i][j][0], troops[i][j][1] // 2, troops[i][j][2] - 1]
                    troops[i][j][1] = troops[i][j][1] - troops[i][j][1] // 2
                    targs[i + 1][j] = (-1, -1)
        stage = 0
        hhcnt += 1
    if keys[pygame.K_UP]:
        vy -= 1
        time.sleep(0.03)
    if keys[pygame.K_DOWN]:
        vy += 1
        time.sleep(0.03)
    if keys[pygame.K_LEFT]:
        vx -= 1
        time.sleep(0.03)
    if keys[pygame.K_RIGHT]:
        vx += 1
        time.sleep(0.03)
    if stage == 1:
        if sx != -1:
            if troops[sx][sy][0] == 1 and tick-mcooldown>10:
                if keys[pygame.K_w]:
                    movet(sx, sy-1, sx, sy)
                    mcooldown = tick
                elif keys[pygame.K_s]:
                    movet(sx, sy + 1, sx, sy)
                    mcooldown = tick
                elif keys[pygame.K_a]:
                    movet(sx - 1, sy, sx, sy)
                    mcooldown = tick
                elif keys[pygame.K_d]:
                    movet(sx + 1, sy, sx, sy)
                    mcooldown = tick
                elif keys[pygame.K_f] and sx + 1 < wsize and troops[sx+1][sy][0] == 0 and troops[sx][sy][1] > 1 and calch(world[sx][sy]) - calch(world[sx+1][sy]) >= -1:
                    troops[sx+1][sy] = [troops[sx][sy][0], troops[sx][sy][1] // 2, troops[sx][sy][2] - 1]
                    troops[sx][sy][1] = troops[sx][sy][1] - troops[sx][sy][1] // 2
                    mcooldown = tick
    if vx < 0:
        vx = 0
    if vx >= wsize:
        vx = wsize - 1
    if vy < 0:
        vy = 0
    if vy >= wsize:
        vy = wsize - 1
    for ev in pygame.event.get():
        if ev.type == pygame.QUIT:
            pygame.quit()
            exit()
    tick += 1
    while time.time()-ticktime < 0.02:
        time.sleep(0.001)
    stage %= 3
    pygame.display.update()
